package main

import (
	"Golang/12December/20241201/web/api"
)

func main() {
	api.InitRouter()
}
