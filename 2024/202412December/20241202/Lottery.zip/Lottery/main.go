package main

import "Golang/12December/20241202/Lottery/api"

func main() {
	api.InitRouter()
}
